﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A16
{
    public partial class Form1 : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\A16.mdf;Integrated Security=True");
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            PopuniComboPas();
            PopuniComboIzlozba();
            PopuniComboKategorija();
        }
        private void PopuniComboPas()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = "SELECT PasID, CONCAT(PasId,' - ',Ime) AS ImePsa FROM Pas";
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dtc = new DataTable();
            try
            {
                da.Fill(dtc);
                comboBoxPas.DataSource = dtc;
                comboBoxPas.DisplayMember = "ImePsa";
                comboBoxPas.ValueMember = "PasID";
                comboBoxPas.SelectedIndex = 0;
            }
            catch
            {
                MessageBox.Show("Doslo je do greške!");
            }
            finally
            {
                da.Dispose();
                cmd.Dispose();
            }
        }
        private void PopuniComboIzlozba()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = "SELECT IzlozbaID, CONCAT(IzlozbaID,' - ',Mesto,' - ', CONVERT(VARCHAR(10),Datum,105)) AS Naziv FROM Izlozba";
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dtc = new DataTable();
            try
            {
                da.Fill(dtc);
                comboBoxIzlozba.DataSource = dtc;
                comboBoxIzlozba.DisplayMember = "Naziv";
                comboBoxIzlozba.ValueMember = "IzlozbaID";
                comboBoxIzlozba2.DataSource = dtc;
                comboBoxIzlozba2.DisplayMember = "Naziv";
                comboBoxIzlozba2.ValueMember = "IzlozbaID";
            }
            catch
            {
                MessageBox.Show("Doslo je do greške!");
            }
            finally
            {
                da.Dispose();
                cmd.Dispose();
            }
        }
        private void PopuniComboKategorija()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = "SELECT KategorijaID, CONCAT(KategorijaID,' - ',Naziv) AS ImeKategorije FROM Kategorija";
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dtc = new DataTable();
            try
            {
                da.Fill(dtc);
                comboBoxKategorija.DataSource = dtc;
                comboBoxKategorija.DisplayMember = "ImeKategorije";
                comboBoxKategorija.ValueMember = "KategorijaID";
                comboBoxKategorija.SelectedIndex = 0;
            }
            catch
            {
                MessageBox.Show("Doslo je do greške!");
            }
            finally
            {
                da.Dispose();
                cmd.Dispose();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBoxPas.Text == "" || comboBoxIzlozba.Text == "" || comboBoxKategorija.Text == "")
            {
                MessageBox.Show("Popunite podatke");
            }
            else
            {
                try
                {
                    SqlCommand command = new SqlCommand("INSERT INTO Rezultat(IzlozbaID, KategorijaID, PasID) VALUES(@Izlozba, @Kategorija, @Pas)", conn);
                    command.Parameters.AddWithValue("@Izlozba", comboBoxIzlozba.SelectedValue);
                    command.Parameters.AddWithValue("@Kategorija", comboBoxKategorija.SelectedValue);
                    command.Parameters.AddWithValue("@Pas", comboBoxPas.SelectedValue);
                    SqlDataAdapter da = new SqlDataAdapter(command);
                    DataTable dtc = new DataTable();
                    da.Fill(dtc);
                    MessageBox.Show("Uspešan unos");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
